The Tagalog Tagset was designed by Nathaniel Oco.
The words for the Tagger Dictionary were taken from the Philippine Literature Domain of Dalos D. Miguel's Comparative Analysis of Tagalog POS Taggers.
The Tagger Dictionary and the Tagset are made available under LGPL.

The Trigram Training Data is available at: https://sourceforge.net/projects/tattoi.u/files/Trigram%20Text/
 
Copyright 2011, Nathaniel Oco and Allan Borra
