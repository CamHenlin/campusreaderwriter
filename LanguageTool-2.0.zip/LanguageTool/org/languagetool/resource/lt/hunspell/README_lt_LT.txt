ispell-lt
=========

You are looking at the dictionaries and affix files for spellchecking
of Lithuanian texts.

The latest version of the affix tables and dictionaries can be found
at ftp://ftp.akl.lt/ispell-lt/ .  The mailing list of the project is
available at https://lists.akl.lt/mailman/listinfo/ispell-lt .  A
browsable web interface to the project CVS repository is available at
http://sraige.mif.vu.lt/cvs/ispell-lt/

The software is available under the provisions of a BSD-style license.
The full text of the license is available in the COPYING file.

The project has been sponsored by the Information Society Development
Committee of the Government of Republic of Lithuania.

Albertas Agejevas <alga@akl.lt>
________________
Updated for Open Office V3.0 version by Ignas2526
