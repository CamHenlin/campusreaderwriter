This Russian dictionary is partially converted to morfologik-speller format by Yakov Reztsov in 2012 from
http://www.aot.ru  (http://sourceforge.net/projects/seman/)
License: LGPL.
Source dictionary:
http://seman.svn.sourceforge.net/viewvc/seman/trunk/Dicts/SrcMorph/RusSrc/morphs.mrd?revision=99
Corrections:  Yakov Reztsov
